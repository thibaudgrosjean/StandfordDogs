# Whatadog Predictor (app for the dog classifier)

## Requirements:
* Python
* 450mb of free disk space

## How to use:
* Install requirements with "pip install -r requirements.txt"
* Launch the app with "streamlit run app.py"
* Open an image file using drag & drop or the explorer to obtain predictions

